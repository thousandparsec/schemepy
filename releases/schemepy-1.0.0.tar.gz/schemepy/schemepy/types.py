import weakref

from schemepy.exceptions import *

from skime.skime.types.symbol import Symbol
from skime.skime.types.pair import Pair as Cons
from lam import Lambda
